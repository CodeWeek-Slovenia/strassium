export const accType = {
    CONSUMER: 'consumer',
    PROVIDER: 'provider',
    NONE:'none'
}