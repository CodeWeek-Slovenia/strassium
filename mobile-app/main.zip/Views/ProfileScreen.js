import React, { cloneElement, useState } from "react";
import { Image, View, StyleSheet, Text, Pressable} from "react-native";
import { loggingOut } from "../Firebase/methods";
import { col } from "./clr";
import MainBackground from './CustomBackground'

import firebase from '../Firebase/firebase';

const MainScreen = ({ navigation }) => {
    const auth = firebase.auth();
    const onLogout = async () => {
        try {
            console.log('logging out')
              await loggingOut();
              
          } catch (error) {
            console.log(error.message)
          }
    }
    return (
        <MainBackground style={styles.container}>
            <View style={styles.profilePictureContainer}>
                <Image source={require("./Icons/aljaz_sovic.png")} style={styles.profilePictureStyle} />
            </View>
            <View style={styles.textContainer}>
                <Text style={styles.textStyle}>{auth.currentUser.displayName}</Text>
                <Text style={styles.textSubStyle2}>Profile type: Consumer</Text>
                <Text style={styles.textSubStyle}>Storage code: 6S9T4R2A0</Text>
            </View>
            <View style={{flex:8,alignItems:"center",justifyContent:"flex-start"}}>
                <Image source={require("./Icons/old_qr.png")}/>
            </View>
            <View style={{flex:1,alignItems:"center",justifyContent:"flex-start"}}>
                <Pressable onPress={onLogout}>
                    <Text>LOGOUT</Text>
                </Pressable>
            </View>
        </MainBackground>
    );
  };
const styles = new StyleSheet.create({
    container:{
        backgroundColor:col.mainColor,
        flex:1
    },
    profilePictureContainer:{
        flex:6,
        justifyContent:"flex-start",
        alignItems:"center",
        marginTop:20
    },
    profilePictureStyle:{
        height: 200,
        width:200,
        borderRadius:100,
    },
    textContainer:{
        flex:5,
        justifyContent:"flex-start",
        alignItems:"center",
    },
    textStyle:{
        color: col.clrText,
        fontFamily:"Bold",
        fontSize:22,
    },textSubStyle:{
        color: col.clrText,
        fontFamily:"Regular",
        fontSize:15,
        paddingTop:4
    },
    textSubStyle2:{
        color: col.clrText,
        fontFamily:"Regular",
        fontSize:20,
        paddingTop:10
    }
});

export default MainScreen;