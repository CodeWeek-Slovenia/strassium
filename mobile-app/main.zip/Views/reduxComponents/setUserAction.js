export const setUser = item => (
    {
      type: 'SET_USER',
      payload:item
    }
  );