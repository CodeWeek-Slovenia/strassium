export const storageUpdate = item => (
    {
      type: 'STORAGE_UPDATE',
      payload:item
    }
  );