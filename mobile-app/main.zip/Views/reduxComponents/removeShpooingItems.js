export const removeShoppingItems = item => (
    {
      type: 'SHOPPING_REMOVE_ITEMS',
      payload:item
    }
  );