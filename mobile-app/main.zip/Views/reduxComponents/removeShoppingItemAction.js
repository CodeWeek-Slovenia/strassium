export const removeShoppingItem = item => (
    {
      type: 'SHOPPING_REMOVE',
      payload: item,
    }
  );