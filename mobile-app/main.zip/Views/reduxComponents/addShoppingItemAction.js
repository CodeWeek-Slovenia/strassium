export const addShoppingItem = item => (
    {
      type: 'SHOPPING_ADD',
      payload:item
    }
  );