export const addPost = item => (
    {
      type: 'ADD_POST',
      payload:item
    }
  );