export const setLoading = item => (
    {
      type: 'LOADING_SET',
      payload:item
    }
  );