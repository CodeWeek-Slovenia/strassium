export const removeShoppingSingleItem = item => (
    {
      type: 'SHOPPING_REMOVE_SINGLE',
      payload: item,
    }
  );