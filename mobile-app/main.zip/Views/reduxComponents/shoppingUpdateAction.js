export const shoppingUpdate = item => (
    {
      type: 'SHOPPING_UPDATE',
      payload:item
    }
  );