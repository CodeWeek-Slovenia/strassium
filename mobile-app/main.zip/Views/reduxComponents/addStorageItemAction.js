export const addStorageItem = item => (
    {
      type: 'STORAGE_ADD',
      payload:item
    }
  );