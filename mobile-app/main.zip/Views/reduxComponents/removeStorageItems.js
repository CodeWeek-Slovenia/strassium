export const removeStorageItems = item => (
    {
      type: 'STORAGE_REMOVE_ITEMS',
      payload:item
    }
  );