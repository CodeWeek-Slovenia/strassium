export const removeStorageSingleItem = item => (
    {
      type: 'STORAGE_REMOVE_SINGLE',
      payload: item,
    }
  );