export const accTypeChange = item => (
    {
      type: 'ACC_TYPE_CHANGE',
      payload:item
    }
  );